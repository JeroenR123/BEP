# -*- coding: utf-8 -*-
"""
Created on Wed Dec 11 15:42:44 2019

@author: s160217
"""

#ANN
# Importing the libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# Importing the dataset
dataset = pd.read_excel('Final analyses/data export.xlsx')
dataset = dataset.fillna(0)
X = dataset.iloc[:, 2]
y = dataset.iloc[:, -1]

y = y.values
X_opt = X.values

import statsmodels.api as sm
X_opt= sm.add_constant(X_opt)
est = sm.OLS(y, X_opt)
est2 = est.fit()
print(est2.summary())

