#Data creation
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# Importing the dataset
dataset_1 = pd.read_excel('Data creation/extract id accomplishment subtotal.xlsx') #extracts form Gamebus
dataset_2 = pd.read_excel('Data creation/id-grow binary.xlsx') #start questionaire growth
dataset_3 = pd.read_excel("Data creation/Create 5 big score.xlsx") #finalquestionaire big 5 personality

rowzeros = []
for i in range(0,len(dataset_1)):
    rowzeros.append(0)
    
dataset_1['grow'] = rowzeros
for index1, row1 in dataset_1.iterrows():
    for index2, row2 in dataset_2.iterrows():
        if row1['uid'] == row2['uid']:
            dataset_1.set_value(index1,'grow', 1)
listie = []
for index1, row1 in dataset_1.iterrows():
    if row1['grow'] == 0:
        listie.append(index1)

dataset_final = dataset_1.drop(listie)
   
rowzeros = []
for i in range(0,len(dataset_final)):
    rowzeros.append(0)
    
dataset_final['grow'] = rowzeros
for index1, row1 in dataset_final.iterrows():
    for index2, row2 in dataset_2.iterrows():
        if row1['uid'] == row2['uid']:
            dataset_final.set_value(index1,'grow', row2['grow'])
            
            
dataset_final['AGREE'] = rowzeros
for index1, row1 in dataset_final.iterrows():
    for index2, row2 in dataset_3.iterrows():
        if row1['uid'] == row2['uid']:
            dataset_final.set_value(index1,'AGREE', 1)
listie = []
for index1, row1 in dataset_final.iterrows():
    if row1['AGREE'] == 0:
        listie.append(index1)
        
dataset_final = dataset_final.drop(listie)    
rowzeros = []
for i in range(0,len(dataset_final)):
    rowzeros.append(0)        
        
for index1, row1 in dataset_final.iterrows():
    for index2, row2 in dataset_3.iterrows():
        if row1['uid'] == row2['uid']:
            dataset_final.set_value(index1,'EXTRA', row2['EXTRA'])
            dataset_final.set_value(index1,'AGREE', row2['AGREE'])
            dataset_final.set_value(index1,'CONS', row2['CONS'])
            dataset_final.set_value(index1,'NEURO', row2['NEURO'])
            dataset_final.set_value(index1,'INT', row2['INT'])
            
            
dataset_final = dataset_final.reset_index(drop=True)    
for index1, row1 in dataset_final.iterrows():
    if row1['treatment']== 1:
        dataset_final.set_value(index1,'treatment', 0)
    elif row1['treatment']== 2:
        dataset_final.set_value(index1,'treatment', 1)
 
def create_score(df):
    #create a extra column in dataframe which consitst of a score,
    #the score is created by the sum of al the views

    score_list = []
    for row_nr in range(0,len(df)):
        v_act = df['view_activities'][row_nr]
        v_lead = df['view_leaderboard'][row_nr]
        v_lead_detail = df['view_leaderboard_detail'][row_nr]
        score = v_act + v_lead + v_lead_detail
        score_list.append(score)
    df['score'] = score_list

create_score(dataset_final)
dataset_final = dataset_final.reset_index(drop=True)
dataset_final.to_excel('data export.xlsx')
