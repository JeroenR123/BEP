#Multiple linear regression model
# Importing the libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# Importing the dataset
dataset = pd.read_excel('data export.xlsx')
dataset = dataset.iloc[:, 1:]
dataset = dataset.fillna(0)
dataset = dataset.reset_index(drop=True)

X = dataset.iloc[:, [14]]
y = dataset.iloc[:, -1]

	

# Splitting the dataset into the Training set and Test set
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.2, random_state = 0)
from sklearn.model_selection import KFold
from sklearn.model_selection import train_test_split

from sklearn.metrics import mean_absolute_error
from sklearn.linear_model import LinearRegression
regressor = LinearRegression()
kf = KFold(n_splits=5)
kf.get_n_splits(X,y)
maes = []
#K fold validation k = 5
for train_index, test_index in kf.split(X,y):
	X_train, X_test = X.iloc[train_index], X.iloc[test_index]
	y_train, y_test = y.iloc[train_index], y.iloc[test_index]
	regressor.fit(X_train, y_train)
	y_pred = regressor.predict(X_test)
	mae = mean_absolute_error(y_test, y_pred)
	maes.append(mae)


# Predicting the Test set results

maelm = sum(maes)/5

