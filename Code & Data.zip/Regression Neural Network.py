#ANN
# Importing the libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# Importing the dataset
dataset = pd.read_excel('data export.xlsx')
dataset = dataset.iloc[:, 1:]
dataset = dataset.fillna(0)
dataset = dataset.reset_index(drop=True)

X = dataset.iloc[:, [12,13,14,15,16]]
y = dataset.iloc[:, -1]

	


# Importing the Keras libraries and packages
import keras
from keras.models import Sequential
from keras.layers import Dense
from keras.utils.vis_utils import plot_model

# Fiting and k fold trainging
from sklearn.model_selection import KFold
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error
import matplotlib.pyplot as plt

kf = KFold(n_splits=5)
kf.get_n_splits(X,y)
maes2 = []
#k fold validation k=5
for train_index, test_index in kf.split(X,y):
    X_train, X_test = X.iloc[train_index], X.iloc[test_index]
    y_train, y_test = y.iloc[train_index], y.iloc[test_index]
       # Initialising the ANN
    Neural_regression = Sequential()
    
    # Adding the input layer and the first hidden layer
    Neural_regression.add(Dense(activation="relu", input_dim=5 , units=4, kernel_initializer="normal"))
    
    # Adding the second hidden layer
    Neural_regression.add(Dense(activation="relu", units=4, kernel_initializer="uniform"))
    
    
    # Adding the output layer
    Neural_regression.add(Dense(activation="linear", units=1, kernel_initializer="uniform"))
    
    	# Compiling the ANN
    Neural_regression.compile(optimizer = 'adam', loss = 'mean_absolute_error', metrics = ['mean_absolute_error'])
    history = Neural_regression.fit(X_train, y_train, batch_size = 1, epochs = 100)
    y_pred = Neural_regression.predict_on_batch(X_test)
    mae2 = mean_absolute_error(y_test, y_pred).item()
    maes2.append(mae2)
    plt.plot(history.history['mean_absolute_error'])
    plt.xlabel('epoch')
    plt.ylabel("MAE")
    plt.show()
    
plot_model(Neural_regression, to_file='model_plot-1.png', show_shapes=True, show_layer_names=True)

# Predicting the Test set results
from sklearn.metrics import mean_absolute_error
maerm = sum(maes2)/5


    







